//Kevin Arokia Raja

package contactApp;

import java.util.Vector;
import java.util.Random;

public class ContactService {

    // Create a vector to store contacts.
    private Vector<Contact> myContacts = new Vector<Contact>();

    // Create an int counter to store the number of contacts.
    private int numContacts = 0;

    // Getter for numContacts
    public int getNumContacts() {
        return numContacts;
    }

    // Getter for the list of contacts.
    public Vector<Contact> getContactList() {
        return myContacts;
    }

    // Function to add a contact to the list.
    public void addContact(String fName, String lName, String phoneNumber, String contactAddress) {
        // Validate first name
        if (fName == null || fName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }

        // Validate last name
        if (lName == null || lName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }

        // Validate phone number
        if (phoneNumber == null || phoneNumber.length() != 10 || !phoneNumber.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone number");
        }

        // Validate contact address
        if (contactAddress == null || contactAddress.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }

        // Generate a unique contact ID
        String contactID = generateUniqueId();

        // Create a new contact
        Contact newContact = new Contact(contactID, fName, lName, phoneNumber, contactAddress);

        // Add the contact to the list of contacts.
        myContacts.add(newContact);

        // Increment the number of contacts.
        numContacts++;
    }

    // Function to remove a contact from the list by contact ID.
    public void removeContact(String contactID) {
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }

        if (myContacts.isEmpty()) {
            throw new IllegalArgumentException("There are no contacts saved.");
        }

        Contact contactToRemove = null;
        for (Contact c : myContacts) {
            if (c.getContactID().equals(contactID)) {
                contactToRemove = c;
                break;
            }
        }

        if (contactToRemove != null) {
            myContacts.remove(contactToRemove);
            numContacts--;
            System.out.println("Contact removed.");
        } else {
            System.out.println("Contact not found.");
        }
    }

    // Function to update a contact by contact ID.
    public void updateContact(String contactID, String fName, String lName, String phoneNumber, String contactAddress) {
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }

        if (myContacts.isEmpty()) {
            throw new IllegalArgumentException("There are no contacts to update.");
        }

        Contact contactToUpdate = null;
        for (Contact c : myContacts) {
            if (c.getContactID().equals(contactID)) {
                contactToUpdate = c;
                break;
            }
        }

        if (contactToUpdate != null) {
            // Validate and update the contact fields
            if (fName != null && fName.length() <= 10) {
                contactToUpdate.setFirstName(fName);
            }

            if (lName != null && lName.length() <= 10) {
                contactToUpdate.setLastName(lName);
            }

            if (phoneNumber != null && phoneNumber.length() == 10 && phoneNumber.matches("\\d{10}")) {
                contactToUpdate.setPhoneNumber(phoneNumber);
            }

            if (contactAddress != null && contactAddress.length() <= 30) {
                contactToUpdate.setContactAddress(contactAddress);
            }

            System.out.println("Contact updated.");
        } else {
            System.out.println("Contact not found.");
        }
    }

    private String generateUniqueId() {
        Random rand = new Random();
        String uniqueID;

        do {
            int newID = rand.nextInt(1000000000);
            uniqueID = String.format("%010d", newID);
        } while (contactIdExists(uniqueID));

        System.out.println("New Contact ID created: " + uniqueID);
        return uniqueID;
    }

    private boolean contactIdExists(String contactID) {
        for (Contact c : myContacts) {
            if (c.getContactID().equals(contactID)) {
                return true;
            }
        }
        return false;
    }
}
