//Kevin Arokia Raja

package contactApp;

public class Contact {
    private static int nextId = 1; // Static variable to generate unique IDs
    private int contactID; // Unique ID for each contact
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String contactAddress;

    // constructor
    public Contact(String fName, String lName, String pNumber, String conAddress) {
        // Validate first name
        if (fName == null || fName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }

        // Validate last name
        if (lName == null || lName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }

        // Validate phone number
        if (pNumber == null || pNumber.length() != 10 || !pNumber.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone number");
        }

        // Validate contact address
        if (conAddress == null || conAddress.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }

        this.contactID = generateUniqueId(); // Assign a unique ID
        this.firstName = fName;
        this.lastName = lName;
        this.phoneNumber = pNumber;
        this.contactAddress = conAddress;
    }

    // Getter for contactID
    public int getContactID() {
        return this.contactID;
    }

    public String getName() {
        return this.firstName + " " + this.lastName;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public String getContactAddress() {
        return this.contactAddress;
    }

    // Helper method to generate a unique ID
    private synchronized int generateUniqueId() {
        return nextId++;
    }

    // ... (rest of your setter methods, if needed)
}
